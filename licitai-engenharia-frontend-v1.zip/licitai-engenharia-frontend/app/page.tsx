import Link from "next/link";

export default function Landing() {
  return <main>
    <header className="container nav">
      <Link href="/" className="brand" style={{textDecoration:"none",color:"inherit"}}><i className="mark"/><span>LicitAI<small>Engenharia</small></span></Link>
      <nav className="navlinks"><a href="#produto">Produto</a><a href="#inteligencia">Inteligência</a><a href="#operacao">Operação</a></nav>
      <div className="actions"><Link href="/login" className="btn">Acessar plataforma</Link><Link href="/demo" className="btn goldbtn">Ver demonstração</Link></div>
    </header>
    <section className="container hero">
      <div><div className="eyebrow">Inteligência para engenharia pública</div><h1 className="display">Decisões melhores começam antes da proposta.</h1><p>O LicitAI monitora oportunidades, lê editais, identifica exigências, riscos e prazos críticos e transforma documentos complexos em informação operacional.</p><div className="hero-actions"><Link href="/demo" className="btn goldbtn">Iniciar demonstração</Link><Link href="/login" className="btn">Entrar na plataforma</Link></div></div>
      <div className="hero-visual"><div className="mini-top"><span>LICITAI / CENTRO DE INTELIGÊNCIA</span><span><i className="status-dot"/>OPERACIONAL</span></div><div className="mini-grid"><div className="metric"><strong>24</strong><span>oportunidades monitoradas</span></div><div className="metric"><strong>08</strong><span>riscos elevados</span></div></div><div className="chart"><svg viewBox="0 0 600 170" preserveAspectRatio="none"><path d="M0 132 C70 128,80 95,145 110 S220 60,275 78 S355 44,410 70 S500 34,600 18" fill="none" stroke="#c8a86b" strokeWidth="2"/></svg></div><div className="mini-top" style={{marginTop:12,marginBottom:0}}><span>ÚLTIMA ANÁLISE</span><span>EDITAL PROCESSADO · 18:42</span></div></div>
    </section>
    <section id="produto" className="section"><div className="container"><div className="eyebrow">Uma camada operacional</div><h2>Menos leitura manual.<br/>Mais decisão.</h2><p className="section-intro">O produto foi desenhado para equipes que precisam acompanhar licitações de engenharia sem perder tempo entre portais, documentos, planilhas e prazos.</p><div className="feature-grid"><Feature n="01" title="Monitoramento" text="Oportunidades relevantes entram no radar a partir de fontes públicas e critérios definidos pela empresa."/><Feature n="02" title="Análise documental" text="A inteligência extrai informações explícitas do edital e organiza o conteúdo em uma visão operacional."/><Feature n="03" title="Radar de risco" text="Riscos contratuais, técnicos e prazos críticos ficam visíveis antes da decisão de participar."/></div></div></section>
    <section id="inteligencia" className="section"><div className="container"><div className="eyebrow">Inteligência aplicada</div><h2>Do documento ao contexto.</h2><p className="section-intro">Cada informação relevante mantém vínculo com sua evidência de origem. O objetivo não é substituir engenharia ou jurídico, mas acelerar a leitura e dar contexto à equipe.</p></div></section>
    <section id="operacao" className="section"><div className="container"><div className="eyebrow">Centro de operações</div><h2>Um ambiente para acompanhar tudo.</h2><p className="section-intro">Dashboard, licitações, análises, riscos, prazos, relatórios, notificações e usuários em um único ambiente empresarial.</p></div></section>
    <footer className="container footer"><span>© 2026 Miller & Co. Software</span><span>LicitAI Engenharia</span></footer>
  </main>
}
function Feature({n,title,text}:{n:string;title:string;text:string}){return <article className="feature"><div className="num">{n}</div><h3>{title}</h3><p>{text}</p></article>}
