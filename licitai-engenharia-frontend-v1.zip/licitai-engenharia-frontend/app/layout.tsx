import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "LicitAI Engenharia",
  description: "Inteligência para decisões em licitações de engenharia.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
