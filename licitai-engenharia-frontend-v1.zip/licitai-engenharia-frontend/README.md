# LicitAI Engenharia — Frontend

Frontend premium do LicitAI Engenharia, construído sobre o backend Supabase existente.

## Arquitetura

- Next.js + React + TypeScript
- Supabase Auth / Data API / RLS
- Supabase Edge Functions para operações privilegiadas
- Sem service_role ou secret keys no navegador
- Demo e ambiente empresarial são experiências distintas

## Configuração

1. Copie `.env.example` para `.env.local`.
2. Preencha `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` com a publishable key do projeto `ldqoknnvyfsfvwtqilnh`.
3. Instale dependências: `npm install`.
4. Rode: `npm run dev`.

## Rotas principais

- `/` landing comercial
- `/demo` demonstração
- `/login` autenticação
- `/onboarding` primeiro acesso / empresa
- `/app/dashboard` dashboard real
- `/app/tenders` licitações
- `/app/tenders/[id]` análise
- `/app/risks` radar de riscos
- `/app/deadlines` prazos
- `/app/reports` relatórios
- `/app/notifications` notificações
- `/app/settings` empresa, usuários e segurança

## Importante

O botão de demonstração atualmente executa a camada visual do fluxo. A execução pública real PNCP → processamento → Claude deve ser ligada a uma Edge Function pública especificamente criada para demo, com rate limiting e sem expor segredos. O cron privado existente não deve ser chamado diretamente pelo browser.
