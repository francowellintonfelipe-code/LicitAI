import { createClient } from "@/lib/supabase/client";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const ONBOARDING_URL = process.env.NEXT_PUBLIC_LICITAI_ONBOARDING_URL || `${SUPABASE_URL}/functions/v1/licitai-onboarding`;

export async function authenticatedFetch(url: string, init: RequestInit = {}) {
  const supabase = createClient();
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  if (!token) throw new Error("Sessão expirada. Entre novamente.");
  const headers = new Headers(init.headers);
  headers.set("Authorization", `Bearer ${token}`);
  headers.set("Content-Type", "application/json");
  return fetch(url, { ...init, headers });
}

export async function createCompany(payload: {
  legal_name: string; trade_name?: string; cnpj: string; email?: string; phone?: string;
}) {
  const response = await authenticatedFetch(ONBOARDING_URL, { method: "POST", body: JSON.stringify(payload) });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || body.message || "Não foi possível criar o ambiente da empresa.");
  return body;
}
