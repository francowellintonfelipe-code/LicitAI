export type RiskLevel = "low" | "medium" | "high" | "critical";
export type TenderStatus = "new" | "processing" | "analyzed" | "error" | "archived";
export type UserRole = "owner" | "admin" | "analyst" | "viewer";

export type Company = {
  id: string;
  legal_name: string;
  trade_name: string | null;
  cnpj: string;
  email: string | null;
  phone: string | null;
};

export type Tender = {
  id: string;
  pncp_id: string;
  title: string;
  object: string | null;
  status: TenderStatus;
  publication_date: string | null;
  proposal_deadline: string | null;
  estimated_value: number | null;
  source_url: string | null;
  agency?: { name: string; city: string | null; uf: string | null } | null;
};

export type Analysis = {
  id: string;
  tender_id: string;
  resumo_objeto: string | null;
  capital_social_minimo: number | null;
  exigencias_crea: string | null;
  bdi_definido: string | null;
  riscos_contratuais: string | null;
  prazos_criticos: Record<string, unknown> | null;
};

export type Risk = {
  id: string;
  analysis_id: string;
  category: string;
  description: string;
  level: RiskLevel;
  evidence: string | null;
};
